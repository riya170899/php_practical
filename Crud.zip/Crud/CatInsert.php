<?php
$category_id="";
$category_name="";
require_once("connect.php");

if (isset($_REQUEST['category_id']))
{
	$category_id=$_REQUEST['category_id'];
	$res=mysqli_query($cn,"select * from category where category_id=$category_id");
	$row=mysqli_fetch_array($res);
	$category_id=$row['category_id'];
}
if (isset($_POST['s1']))
{
	$category_name=$_POST['t1'];
	if(category_id>0)
	{
		$res=mysqli_query($cn,"update category set category_name='$category_name' where category_id=$category_id");
			echo "Update $res";	
	}
	else
	{
		$res=mysqli_query($cn,"Insert into category values (0,'$category_name')");
			echo "Inserted $res";	
	}
	header("Location:CatShow.php");
}
?>

<form method="_POST">
	<table>
		<tr>
			<td>Category Id</td>
	        <td><input type="text" name="h1" value="<?php echo $category_id;?>"></td>
			<td>Category Name</td>
			<td>
			
			<input type="text" name="t1" value="<?php echo $category_name;?>">
		</td>
	</tr>

	<tr>
		<td><input type="submit" name="s1" value="Add Category"></td>
	</tr>

	</table>

	</form>