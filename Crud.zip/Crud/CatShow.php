<?php
require_once("connect.php");
if(isset($_REQUEST['category_id']))
{
	$category_id=$_REQUEST['category_id'];
	mysql_query($cn,"delete from category where category_id=$category_id");
	echo "delete from category where catrgoy_id=$category_id";
}

$res=mysql_query($cn,"select * from category");


?>
<a href="CatInsert.php">New Category</a>
<table border="1">
		<th>Category ID</th>
		<th>Category Name</th>
<?php
		while ($row=mysqli_fetch_object($res))
		 {
			
?>

	<tr>
		<td><?php echo $row->category_id;?></td>
		<td><?php echo $row->category_name;?></td>
		<td><a href="CatShow.php?category_id=<?php echo $row->category_id;?>">Delete</a></td>
		<td><a href="CatInsert.php?category_id=<?php echo $row->category_name;?>">Edit</a></td>
	</tr>
<?php
	}

?>

</table>