<?php
				 //ServerName,Username,password,dbname
$cn=mysqli_connect("localhost","root","","shoppingcart") or die("Error....");

?>