<?php
if(isset($_REQUEST['fname']))
{
	$fname=$_REQUEST['fname'];
	$path="Upload/$fname";
	$fp=fopen("$path","r");
	$size=filesize($path);
	header("Content-Disposition:Attachment;filename=$fname");
	header("Content-type:octec-stream");
	header("Content-Length:$size");
	fpassthru($fp);
}
require_once("connect.php");
$res=mysqli_query($cn,"select p.*,c.category_name from product p,category c where c.category_id=p.category_id");


?>
<center>
	<table border="1">
		<tr>
			<th>Product Id</th>
			<th>Catgeory Name</th>
			<th>Product Name</th>
			<th>Price</th>
			<th>Photo</th>
		</tr>
		<?php
			while($row=mysqli_fetch_assoc($res))
			{


		?>
				<tr>
					<td><?php echo $row['product_id']; ?></td>
					<td><a href="ProductShow.php?fname=<?php echo $row['photo'];?>"><img src="MyUpload/<?php echo $row['photo'];?>" height=150 width=150></a></td>
					<td><?php echo $row['category_name'];?></td>
					<td><?php echo $row['product_name'];?></td>
					<td><?php echo $row['price'];?></td>
					<td><a href="ProductInsert.php?product_id=<?php echo $row['product_id'];?>">Edit</td>
				</tr>

		<?php
			}
		?>
	</table>
</center>