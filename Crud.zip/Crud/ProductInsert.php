<?php
require_once("connect.php");
if (isset($_POST['s1']))
{
	$cat=$_POST['cat'];
	$product_name=$_POST['product_name'];
	$price=$_POST['price'];
	$photo=$_FILES['f1']['name'];
	echo "Size".$_FILES['f1']['size'];
	print_r($_FILES['f1']);
	echo "$photo";
	$path="MyUpload/$photo";
	$res=mysqli_query($cn,"Insert into product values (0,'$cat','$product_name','$price',$photo)");
	move_uploaded_file($_FILES['f1']['tmp_name'], $path);
	echo "Inserted $res";
}


?>



<form method="post" enctype="multipart/form-data">
	<table>
		<tr>
			<td>Category Name</td>
			<td><select name="cat">
				<option>-----Select------- </option>
				<?php  
					$res=mysqli_query($cn,"select * from category");
					while($row=mysqli_fetch_assoc($res))
					{

					
				?>
					<option value="<?php echo $row['category_id']?>" ><?php echo $row['category_name']?></option>

					<?php
						}
					?>
			</select>></td>
		</tr>
		<tr>
			<td>Product Name</td>
			<td><input type="text" name="t1"></td>
		</tr>
		<tr>
			<td>Price</td>
			<td><input type="text" name="t2"></td>
		</tr>
		<tr>
			<td>Photo</td>
			<td><input type="file" name="f1"></td>
		</tr>
		<tr>
			<td><input type="submit" name="s1" value="Add Product"></td>
		</tr>
	</table>
</form>